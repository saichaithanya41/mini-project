from django.shortcuts import render,redirect
from .models import menu_b,menu_l,menu_d,resgistration,feed
from django.contrib.auth.models import User,auth
from django.contrib import messages

def menu(request):
    men = menu_b.objects.all()
    men1 =menu_l.objects.all()
    men2 =menu_d.objects.all()
    return render(request,'menu.html',{'men':men,'men1':men1,'men2':men2})
def home(request):
    return render(request,'home.html',{'price':700})

def book(request):
    name=request.POST['name']
    phone=request.POST['phone']
    day=request.POST['day']
    time=request.POST['hour']
    tableno=int(request.POST['Table no'])
    persons=request.POST['persons']
    if User.objects.filter(first_name=name).exists():
        if resgistration.objects.filter(tableno=tableno,day=day,time=time).exists():
            messages.info(request,'table already reserved...')
        else:
            messages.info(request,'booking table...')
            registar=resgistration()
            registar.name=name
            registar.phone=phone
            registar.day=day
            registar.time=time
            registar.tableno=tableno
            registar.persons=persons
            registar.save()
            messages.info(request,'congratulations table booked sucessfully')
    else:
        messages.info(request,'invalid name')
    return redirect('home')

def login(request):
    
    return render(request,'index.html')
def register(request):
    first_name=request.POST['first_name']
    username=request.POST['username']
    password1=request.POST['password1']
    password2=request.POST['password2']
    email=request.POST['email']

    if password1 == password2:
        if User.objects.filter(username=username).exists():
            messages.info(request,'user name taken.')
        elif User.objects.filter(email=email).exists():
            messages.info(request,'email exist')
        else:
            user=User.objects.create_user(username=username,password=password1,email=email,first_name=first_name)
            user.save()
            messages.info(request,'user created')
    else:
        messages.info(request,'password didnot match')
    return redirect('/')
def check(request):
    username=request.POST['username']
    password=request.POST['password']

    user = auth.authenticate(username=username,password=password)

    if user is not None:
        return redirect('home')
    else:
        messages.info(request,'enter a valid user name and password')
        return redirect('/')
def feedback(request):
    return render(request,'feedback.html')
def feedbacksub(request):
    name=request.POST['name']
    comment=request.POST['comments']
    feedd=feed()
    feedd.name=name
    feedd.comment=comment
    feedd.save()
    messages.info(request,'thanks for giving fedback ')
    return redirect('feedback')
def contact(request):
    return render(request,'contact.html')
def logout(request):
    return redirect('/')
