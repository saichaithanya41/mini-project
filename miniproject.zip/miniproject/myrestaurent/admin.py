from django.contrib import admin
from .models import menu_b,menu_l,menu_d,resgistration,feed
# Register your models here.
admin.site.register(menu_b)
admin.site.register(menu_l)
admin.site.register(resgistration)
admin.site.register(menu_d)
admin.site.register(feed)
