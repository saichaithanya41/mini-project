from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class menu_b(models.Model):
    name=models.CharField(max_length=50)
    img=models.ImageField(upload_to='pics')
    desc=models.TextField()
    price=models.IntegerField() 

class menu_l(models.Model):
    name=models.CharField(max_length=50)
    img=models.ImageField(upload_to='pics')
    desc=models.TextField()
    price=models.IntegerField()

class menu_d(models.Model):
    name=models.CharField(max_length=50)
    img=models.ImageField(upload_to='pics')
    desc=models.TextField()
    price=models.IntegerField()

class resgistration(models.Model):
    name=models.CharField(max_length=50)
    phone=models.CharField(max_length=80)
    day=models.CharField(max_length=50)
    time=models.CharField(max_length=50)
    tableno=models.IntegerField()
    persons=models.CharField(max_length=50)

class feed(models.Model):
    name=models.CharField(max_length=50)
    comment=models.CharField(max_length=150)

