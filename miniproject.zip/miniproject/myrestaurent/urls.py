from django.urls import path
from . import views

urlpatterns =[
    path('',views.login,name='login'),
    path('home',views.home,name='home'),
    path('menu',views.menu,name='menu'),
    path('book',views.book,name='book'),
    path('register',views.register,name='register'),
    path('check',views.check,name='check'),
    path('feedback',views.feedback,name='feedback'),
    path('feedbacksub',views.feedbacksub,name='feedbacksub'),
    path('contact',views.contact,name='contact'),
    path('logout',views.logout,name='logout')

]
